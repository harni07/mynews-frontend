import React from 'react';

const DashboardContainer = ({ title, component: Component, props  }: any) => {
    return (
        <div className="col-md-6"> 
            <div className="container-style">
                <h3>{title}</h3>
                <Component {...props}/>
            </div>
        </div>
    );
};

export default DashboardContainer;
