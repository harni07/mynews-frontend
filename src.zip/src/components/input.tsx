import React from "react";

interface InputProps {
    label: string;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    placeholder: string;
    type?: string;
}

const Input: React.FC<InputProps> = ({ label, value, onChange, placeholder, type = "text" }) => (
    <div className="col-md-4">
        <label className="form-label">{label}</label>
        <input
            type={type}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className="form-control"
        />
    </div>
);

export default Input;
