import React from "react";

interface CheckboxProps {
    label: string;
    checked: boolean;
    onChange: () => void;
}

const Checkbox: React.FC<CheckboxProps> = ({ label, checked, onChange }) => (
    <label className="form-check-label me-2">
        <input
            type="checkbox"
            checked={checked}
            onChange={onChange}
            className="form-check-input me-1"
        />
        {label}
    </label>
);

export default Checkbox;
