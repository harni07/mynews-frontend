import React, {useEffect, useState} from 'react';
import {Container, Dropdown, Nav, Navbar, NavDropdown} from "react-bootstrap";
import {useNavigate} from "react-router-dom";
import Dashboard from "../pages/dashboard";
import Notification from "./notification";
import {useDispatch, useSelector} from "react-redux";
import {removeToast} from "../store/slices/toast";

interface IPublicLayout {
    children: React.ReactNode
}

const Layout = ({children} : IPublicLayout) => {
    const toasts = useSelector((state: any) => state.toast.toasts);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const currentYear = new Date().getFullYear();
    const registerState: any = localStorage.getItem('token');
    const username = registerState ? JSON.parse(registerState).username : null;

    const logout = () => {
        localStorage.removeItem('token');
        navigate("/login")
    }

    const handleCloseToast = (id: any) => {
        dispatch(removeToast(id)); // Dispatch the removeToast action
    };

    return (
       <>
           <Navbar expand="lg" className="bg-body-tertiary" data-bs-theme="dark">
               <Container>
                   <Navbar.Brand href="/"><img className='logo' src="https://media.warriortrading.com/2020/03/shutterstock_310733441.jpg" alt=""/> Journal4x</Navbar.Brand>
                   <Navbar.Toggle aria-controls="basic-navbar-nav" />
                   <Navbar.Collapse id="basic-navbar-nav">
                       <Nav className="me-auto">
                           <Nav.Link href="/dashboard">Analytics</Nav.Link>
                           <Nav.Link href="/trades">Trades</Nav.Link>
                           <Nav.Link href="/trading-plan">Trading plan</Nav.Link>
                       </Nav>

                       <NavDropdown title={username} id="basic-nav-dropdown" className='username-color'>
                           <Dropdown.Item href="/profile" >Profile</Dropdown.Item>
                           <Dropdown.Item disabled>Risk calculator</Dropdown.Item>
                           <Dropdown.Item onClick={() => logout()}>Log out</Dropdown.Item>
                       </NavDropdown>
                   </Navbar.Collapse>
               </Container>
           </Navbar>
           {toasts.map((toast: any) => (
               <Notification
                   key={toast.id}
                   show={true}
                   onClose={() => handleCloseToast(toast.id)}
                   title={toast.title}
                   message={toast.message}
               />
           ))}
           <div className='main-background'>
               <Container className='main-content' fluid='xxl'>
                   {children}
               </Container>
           </div>
           <footer style={{background: "black"}}>
               <Container className='py-3 text-center text-white'>
                   Copy @{currentYear}
               </Container>
           </footer>


       </>
    );
}

export default Layout;
