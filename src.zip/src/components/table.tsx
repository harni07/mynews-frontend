import React, {useState} from 'react';
import { Button } from 'react-bootstrap';
import { Trade } from '../models/trade';
import TradeModal from "./modal";
import '../styles/components/card.scss';
import CustomModal from "./custom-modal";

const TradesTable = ({ data, deleteTrade, handleCloseModal }: any) => {


    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [deleteTitle, setDeleteTitle] = useState('');
    const [deleteMessage, setDeleteMessage] = useState('');
    const [tradeId, setTradeId] = useState(0);

    const [imageUrl, setImageUrl] = useState('');

    const handleImageClick = (image:string) => {
        setImageModalVisible(true);
        setImageUrl(image);
    }

    const openDeleteModal = async (tradeId: number) => {
        setTradeId(tradeId);
        setDeleteTitle('Delete Trade');
        setDeleteMessage('Are you sure you want to delete this trade?');
        setShowDeleteModal(true);
    };

    const handleClose = () => {
        setShowDeleteModal(false);
    };

    const handleCloseImageModal = () => {
        setImageModalVisible(false);
    }

    const [isImageModalVisible, setImageModalVisible] = useState(false);

    return (

        <div className="nft-container">
            {data?.data?.map((trade: Trade) => (
                <div className="nft" key={trade.id}>
                    <div className='main'>
                        <img
                            className='tokenImage'
                            src={trade.image ? trade.image : "https://storage.googleapis.com/proudcity/mebanenc/uploads/2021/03/placeholder-image.png"}
                            alt="Trade image"
                            onClick={() => handleImageClick(trade.image)}
                        />
                        <h2>{trade.pair !== '' ? trade.pair : '-'}</h2>
                        <p className='description'>
                            {trade.buy ? 'Buy' : 'Sell'}
                        </p>
                        <div className='tokenInfo'>
                            <div className={`price ${trade.profit < 0 ? 'negative' : ''}`}>
                                <p>
                                    ${trade.profit ?? '-'}
                                </p>
                            </div>
                            <div className="duration">
                                <p>{new Date(trade.created_at).toLocaleDateString()}</p>
                            </div>
                        </div>
                        <hr />
                        <div className='creator'>
                            <div className="actions">
                                <TradeModal buttonTitle='Edit' initialTrade={trade} onTradeSaved={handleCloseModal}/>
                                <Button variant="danger" onClick={() => openDeleteModal(trade.id)}>Delete</Button>
                            </div>
                        </div>
                    </div>
                </div>
            ))}

            {
                isImageModalVisible &&
                <div
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',  // semi-transparent black
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        zIndex: 1000  // ensure it's on top
                    }}
                    onClick={handleCloseImageModal}  // close on click outside
                >
                    <img src={imageUrl} alt="Trade Image in Full Screen" style={{maxWidth: '90%', maxHeight: '90%'}} />
                </div>
            }
            <CustomModal
                show={showDeleteModal}
                handleClose={handleClose}
                title={deleteTitle}
                confirmButtonVariant='danger'
                actionTitle='Delete'
                content={
                    <p>{deleteMessage}</p>
                }
                onSubmit={() => deleteTrade(tradeId, handleClose)}
            />
        </div>

    );
};

export default TradesTable;
