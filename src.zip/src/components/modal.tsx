import {useEffect, useState} from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import {useCreateTradeMutation, useUpdateTradeMutation} from "../services/trades";
import {TradeModalProps} from "../models/trade";
import {useDispatch} from "react-redux";
import {addToast} from "../store/slices/toast";
import {Simulate} from "react-dom/test-utils";

function TradeModal({ initialTrade, buttonTitle, onTradeSaved, buttonClass = ''}: TradeModalProps) {
    const [mode, setMode] = useState<'Create' | 'Edit'>('Create');
    const registerState: any = localStorage.getItem('token');
    const userId = JSON.parse(registerState).id;
    const [createTrade] = useCreateTradeMutation();
    const [updateTrade] = useUpdateTradeMutation();
    const [buy, setBuy] = useState(true);
    const [sell, setSell] = useState(false);
    const [entryPrice, setEntryPrice] = useState("");
    const [closedPrice, setClosedPrice] = useState("");
    const [stopLoss, setStopLoss] = useState("");
    const [takeProfit, setTakeProfit] = useState("");
    const [tradeReason, setTradeReason] = useState("");
    const [pair, setPair] = useState("");
    const [image, setImage] = useState(null);
    const [show, setShow] = useState(false);
    const [profit, setProfit] = useState('');
    const [outcome, setOutcome] = useState('');
    const [pips, setPips] = useState('');
    const [mistakeDescription, setMistakeDescription] = useState("");
    const [couldDoneBetter, setCouldDoneBetter] = useState("");


    const dispatch = useDispatch();

    const showToast = (message: string, title: string) => {
        const toast = { id: Date.now(), title, message };
        dispatch(addToast(toast));
    };

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);


    const handleImageChange = (e: any) => {
        setImage(e.target.files[0]);
    };

    const closeModal = () => {
        onTradeSaved();
    }

    const handleSubmit = async (e: any) => {
        e.preventDefault();


        const formData = new FormData();

        const tradeData: { [key: string]: any } = {
            buy: buy,
            sell: sell,
            entry_price: Number(entryPrice),
            closed_price: Number(closedPrice),
            stop_loss: Number(stopLoss),
            take_profit: Number(takeProfit),
            trade_reason: tradeReason,
            pair,
            userId: userId,
            profit: Number(profit),
            outcome: Number(outcome),
            pips: Number(pips),
            mistakeDescription: mistakeDescription,
            couldDoneBetter: couldDoneBetter,
        };

        for (let key in tradeData) {
            formData.append(key, tradeData[key]);
        }

        if (image) {
            // @ts-ignore
            formData.append('image', image, image.name);
        }
        if (mode === 'Create') {
            await createTrade(formData);
            showToast('Create trade', 'Trade created successfully!')
        } else {
            await updateTrade({trade: formData, tradeId: initialTrade?.id});
            showToast('Edit trade', 'Trade edited successfully!')
        }
        closeModal();
        handleClose();
    };

    useEffect(() => {
        if (initialTrade) {
            setMode('Edit');
            setBuy(initialTrade.buy);
            setSell(initialTrade.sell);
            setEntryPrice(initialTrade.entry_price.toString());
            setClosedPrice(initialTrade.closed_price.toString());
            setStopLoss(initialTrade.stop_loss.toString());
            setTakeProfit(initialTrade.take_profit.toString());
            setProfit(initialTrade.profit.toString());
            setOutcome(initialTrade.outcome.toString());
            setPips(initialTrade.pips.toString());
            setPair(initialTrade.pair);
            setMistakeDescription(initialTrade.mistakeDescription);
            setCouldDoneBetter(initialTrade.couldDoneBetter);
            setTradeReason(initialTrade.trade_reason);
        } else {
            setMode('Create');
        }
    }, [initialTrade]);

    return (
        <>
            <Button variant="primary" className={buttonClass} onClick={handleShow}>
                {buttonTitle}
            </Button>

            <Modal show={show} onHide={handleClose} size="xl">
                <Modal.Header closeButton>
                    <Modal.Title>{mode === 'Create' ? 'Create new' : 'Edit'} trade</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <form className="container mt-3">
                        <div className="row mb-3">
                            <div className="col-md-3">
                                <label className="form-label">Entry Price</label>
                                <input type="number" value={entryPrice} onChange={(e) => setEntryPrice(e.target.value)} placeholder="Entry Price" className="form-control" />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Closed Price</label>
                                <input type="number" value={closedPrice} onChange={(e) => setClosedPrice(e.target.value)} placeholder="Closed Price" className="form-control" />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Stop Loss</label>
                                <input type="number" value={stopLoss} onChange={(e) => setStopLoss(e.target.value)} placeholder="Stop Loss" className="form-control" />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Take Profit</label>
                                <input type="number" value={takeProfit} onChange={(e) => setTakeProfit(e.target.value)} placeholder="Take Profit" className="form-control" />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <div className="col-md-3">
                                <label className="form-label">Pair</label>
                                <input type="text" value={pair} onChange={(e) => setPair(e.target.value)} placeholder="Pair" className="form-control" />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Profit</label>
                                <input type="number" value={profit} onChange={(e) => setProfit(e.target.value)} placeholder="Profit" className="form-control" />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Outcome</label>
                                <input type="number" value={outcome} onChange={(e) => setOutcome(e.target.value)} placeholder="Outcome" className="form-control" />
                            </div>
                            <div className="col-md-3">
                                <label className="form-label">Pips</label>
                                <input type="number" value={pips} onChange={(e) => setPips(e.target.value)} placeholder="Pips" className="form-control" />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <div className="col-6">
                                <label className="form-label">Mistake</label>
                                <input type="text" value={mistakeDescription} onChange={(e) => setMistakeDescription(e.target.value)} placeholder="Mistake Reason" className="form-control" />
                            </div>

                            <div className="col-6">
                                <label className="form-label">Could Have Done Better</label>
                                <input type="text" value={couldDoneBetter} onChange={(e) => setCouldDoneBetter(e.target.value)} placeholder="Could Have Done Better" className="form-control" />
                            </div>
                        </div>
                        <div className="mb-12">
                            <div className="col-md-12">
                                <label className="form-label">Trade Reason</label>
                                <textarea value={tradeReason} onChange={(e) => setTradeReason(e.target.value)} placeholder="Trade Reason" className="form-control"></textarea>
                            </div>
                        </div>
                        <div className="row mt-3 mb-3">
                            {initialTrade?.image && (
                                <div  className="col-4">
                                    <label className="form-label">Image preview </label>
                                    <div className="current-image">
                                        <img src={initialTrade?.image} alt="Current Trade Image" />
                                    </div>
                                </div>
                            )}
                            <div className={initialTrade ? 'col-8' : 'col-12'}>
                                {!initialTrade?.image &&
                                    <label className="form-label">Add Image</label>
                                }
                                {initialTrade?.image &&
                                    <label className="form-label">Change Image</label>
                                }
                                <input type="file" onChange={handleImageChange} className="form-control" />
                            </div>
                        </div>
                        <div className="mb-3">
                            <label className="form-check-label me-2">
                                <input type="checkbox" checked={buy} onChange={() => { setBuy(!buy); setSell(buy)}} className="form-check-input me-1" />
                                Buy
                            </label>
                            <label className="form-check-label">
                                <input type="checkbox" checked={sell} onChange={() => {
                                    setSell(!sell)
                                    setBuy(sell)
                                }} className="form-check-input me-1" />
                                Sell
                            </label>
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button className='journal-button' onClick={handleSubmit}>
                        {mode} trade
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default TradeModal;
