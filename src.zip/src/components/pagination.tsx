import React from 'react';
import {PaginationModel} from "../models/trade";

const Pagination = ({ currentPage, totalItems, itemsPerPage, onPageChange }: PaginationModel)  => {
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    const handleClick = (pageNumber: number) => {
        if (pageNumber >= 1 && pageNumber <= totalPages) {
            onPageChange(pageNumber);
        }
    };

    return (
        <div className="pagination-wrapper">
            <button className="pagination-button" onClick={() => handleClick(currentPage - 1)}>Previous</button>
            {Array.from({ length: totalPages }).map((_, index) => (
                <button
                    key={index}
                    className={`pagination-button ${currentPage === index + 1 ? 'pagination-active' : ''}`}
                    onClick={() => handleClick(index + 1)}
                    disabled={currentPage === index + 1}
                >
                    {index + 1}
                </button>
            ))}
            <button className="pagination-button" onClick={() => handleClick(currentPage + 1)}>Next</button>
        </div>
    );
};

export default Pagination;
