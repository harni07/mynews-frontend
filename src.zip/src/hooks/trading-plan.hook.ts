import { useState, useEffect } from 'react';
import {
    useGetRulesMutation,
    useDeleteRuleMutation,
    useCreateRuleMutation,
    useEditRuleMutation,
    useGetTipsMutation,
    useDeleteTipMutation,
    useCreateTipMutation,
    useEditTipMutation,
} from '../services/trading_plan';

export function useTradingPlan() {
    const [getRules, { data: rules }] = useGetRulesMutation();
    const [sendDeleteRule] = useDeleteRuleMutation();
    const [createNewRule] = useCreateRuleMutation();
    const [editRule] = useEditRuleMutation();
    const [getTips, { data: tips }] = useGetTipsMutation();
    const [sendDeleteTip] = useDeleteTipMutation();
    const [createNewTip] = useCreateTipMutation();
    const [editTip] = useEditTipMutation();

    useEffect(() => {
        getRules('');
        getTips('');
    }, []);

    return {
        rules,
        tips,
        createNewRule: createNewRule,
        editRule,
        deleteRule: sendDeleteRule,
        createNewTip: createNewTip,
        editTip,
        deleteTip: sendDeleteTip,
        getRules,
        getTips,
    };
}
