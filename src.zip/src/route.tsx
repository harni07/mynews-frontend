import {createBrowserRouter} from "react-router-dom";
import React from "react";
import Login from "./pages/login";
import Register from "./pages/register";
import ForgotPassword from "./pages/forgot-password";
import ResetPassword from "./pages/reset-password";
import AccountActivated from "./pages/account-acctivated";
import Trades from "./pages/trades";
import Profile from "./pages/profile";
import Dashboard from "./pages/dashboard";
import TradingPlan from "./pages/trading-plan";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <Login />
    },
    {
        path: "/trading-plan",
        element: <TradingPlan />
    },
    {
        path: "/dashboard",
        element: <Dashboard />
    },
    {
        path: "/trades",
        element: <Trades />
    },
    {
        path: "/register",
        element: <Register/>,

    },
    {
        path: "/login",
        element: <Login/>
    },
    {
        path: "/profile",
        element: <Profile/>
    },
    {
        path: "/auth/activate/:token",
        element: <AccountActivated/>
    },
    {
        path: "/forgot-password",
        element: <ForgotPassword/>
    },
    {
        path: "/reset-password/:token",
        element: <ResetPassword/>
    }
]);
