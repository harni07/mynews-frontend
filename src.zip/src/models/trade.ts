export interface Trade {
    id: number;
    buy: boolean;
    sell: boolean;
    entry_price: number;
    closed_price: number;
    stop_loss: number;
    take_profit: number;
    trade_reason: string;
    pair: string;
    image: any;
    created_at: string;
    userId: number;
    profit: number;
    outcome: number;
    pips: number;
    mistake: boolean;
    mistakeDescription: string;
    couldDoneBetter: string;
}

export interface Rule {
    id: number;
    rule: string;
    userId: number;
}

export interface Tip {
    id: number;
    tip: string;
    userId: number;
}

export interface TradeModalProps {
    initialTrade?: Trade;
    buttonTitle: string;
    buttonClass?: string;
    onTradeSaved: () => void;
}

export interface PaginationModel {
    currentPage: number;
    totalItems: number;
    itemsPerPage: number;
    onPageChange: (page:number) => void;
}
