import { configureStore } from '@reduxjs/toolkit'
import {toastSlice} from "./slices/toast";
import {authApi} from "../services/auth";
import {setupListeners} from "@reduxjs/toolkit/query";
import {tradesApi} from "../services/trades";
import {tradingPlanApi} from "../services/trading_plan";


export const store = configureStore({
    reducer: {
        toast: toastSlice.reducer,
        [authApi.reducerPath]: authApi.reducer,
        [tradesApi.reducerPath]: tradesApi.reducer,
        [tradingPlanApi.reducerPath]: tradingPlanApi.reducer,
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(authApi.middleware, tradesApi.middleware, tradingPlanApi.middleware),
})

setupListeners(store.dispatch)

export type AppState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
