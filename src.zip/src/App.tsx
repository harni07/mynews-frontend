import React from 'react';
import './App.css';
import Layout from "./components/layout";

const App = () => {

  return (
        <Layout>
        </Layout>
  );
}

export default App;
