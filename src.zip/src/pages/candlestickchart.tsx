import React from 'react';
import ApexCharts from 'react-apexcharts';

const CandlestickChart = ({ candlestickData }: any) => {
    const options: any = {
        chart: {
            type: 'candlestick',
            height: 350,
        },
        title: {
            text: 'Candlestick Pips Chart',
            align: 'left',
        },
        xaxis: {
            type: 'datetime',
        },
        yaxis: {
            tooltip: {
                enabled: true,
            },
            labels: {
                formatter: function (val: number) {
                    return val.toFixed(2);
                }
            }
        },
    };

    return (
        <ApexCharts options={options} series={[{ data: candlestickData }]} type="candlestick" height={350} />
    );
};

export default CandlestickChart;
