import React, {useEffect, useState} from 'react';
import {useLoginMutation} from "../services/auth";
import {useNavigate} from "react-router-dom";
import '../styles/components/login.scss';

const Login = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const [loginUser, { data }] = useLoginMutation();
    const [errorMsg, setErrorMsg] = useState([]);

    const handleSubmit = async (event: any) => {
        event.preventDefault();

        try {
            loginUser({ email, password, first_name: 'davor', last_name: 'harni', username: 'harni07' });
        } catch (error: any) {
            setErrorMsg(error.data?.message);
        }
    };

    useEffect(() => {
        const registerState: any = localStorage.getItem('token');
        const access_token = registerState ? JSON.parse(registerState).access_token : null;
        if (access_token) {
            navigate("/dashboard")
        }
        if (data?.access_token) {
            localStorage.setItem('token', JSON.stringify(data));
            navigate("/trades")
        }
    });


    return (
        <div className="login-container">
            <div className="image-container">
                <img src="https://st2.depositphotos.com/1003476/8276/i/950/depositphotos_82767358-stock-photo-forex-candlestick-chart-over-dark.jpg" alt="test" />
            </div>
            <div className="form-container">
                <div className="box">
                    <div className="form">
                        <form onSubmit={handleSubmit}>
                            <h2>Sign in</h2>
                            <div className="inputBox">
                                <input type="text" required value={email} onChange={(e) => setEmail(e.target.value)}/>
                                <span>Username</span>
                                <i></i>
                            </div>
                            <div className="inputBox">
                                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}/>
                                <span>Password</span>
                                <i></i>
                            </div>
                            {data && <p className='text-danger mt-3'>{data.message}</p>}
                            {errorMsg &&  errorMsg.map((msg:string)=> {
                                return (<p className='text-danger mt-3'>{msg}</p>)
                            })
                            }
                            <div className="links">
                                <a href='/forgot-password'>Forgot Password</a>
                                <a href='/register'>Register</a>
                            </div>
                            <input type="submit" value="Login"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
