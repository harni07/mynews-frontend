import React from 'react';
import { Card, Col, Container, Row } from 'react-bootstrap';
import {
    BsCheckCircle, BsArrowRight, BsGraphUp,
    BsBarChart, BsExclamationTriangle, BsQuestionCircle, BsCurrencyExchange
} from 'react-icons/bs';

const StatsCard = ({ total_trades, num_buys, num_sells, num_pips, win_ratio, outcome, num_mistakes, most_traded_pair }: any) => {
    return (
        <Container>
            <Row className="gx-5">
                <Col md={3} sm={6}>
                    <Card bg="primary" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Total Trades</Card.Title>
                                    <Card.Text>{total_trades}</Card.Text>
                                </div>
                                <BsArrowRight className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="success" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Number of Buys</Card.Title>
                                    <Card.Text>{num_buys}</Card.Text>
                                </div>
                                <BsCheckCircle className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="info" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Number of Sells</Card.Title>
                                    <Card.Text>{num_sells}</Card.Text>
                                </div>
                                <BsCurrencyExchange className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="warning" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Number of Pips</Card.Title>
                                    <Card.Text>{num_pips}</Card.Text>
                                </div>
                                <BsGraphUp className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="danger" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Win Ratio</Card.Title>
                                    <Card.Text>{win_ratio}%</Card.Text>
                                </div>
                                <BsGraphUp className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="secondary" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Outcome</Card.Title>
                                    <Card.Text>${outcome}</Card.Text>
                                </div>
                                <BsBarChart className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="dark" text="white" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Number of Mistakes</Card.Title>
                                    <Card.Text>{num_mistakes}</Card.Text>
                                </div>
                                <BsExclamationTriangle className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} sm={6}>
                    <Card bg="light" className="mb-3 stats-card">
                        <Card.Body>
                            <div className="card-content">
                                <div className="text-content">
                                    <Card.Title>Most Traded Pair</Card.Title>
                                    <Card.Text>{most_traded_pair}</Card.Text>
                                </div>
                                <BsQuestionCircle className="icon" />
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default StatsCard;
