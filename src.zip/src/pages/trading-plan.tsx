import React, {useEffect, useState} from 'react';
import Layout from "../components/layout";
import {Col, Container, Form, Row} from "react-bootstrap";
import {Rule, Tip} from "../models/trade";
import CustomModal from "../components/custom-modal";
import TipTable from "./tip";
import RuleTable from "./rule";
import {useTradingPlan} from "../hooks/trading-plan.hook";

const TradingPlan = () => {
    const {
        rules,
        tips,
        createNewRule,
        editRule,
        deleteRule,
        createNewTip,
        editTip,
        deleteTip,
        getRules,
        getTips,
    } = useTradingPlan();

    const [riskPerTrade, setRiskPerTrade] = useState(2);
    const [showTip, setShowTip] = useState(false);
    const [showRule, setShowRule] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [deleteTitle, setDeleteTitle] = useState('');
    const [deleteMessage, setDeleteMessage] = useState('');
    const [ruleName, setRuleName] = useState('');
    const [tipName, setTipName] = useState('');
    const [ruleId, setRuleId] = useState(0);
    const [tipId, setTipId] = useState(0);
    const [isTipDelete, setIsTipDelete] = useState(false);
    const [createTip, setCreateTip] = useState(false);
    const [createRule, setCreateRule] = useState(false);

    const handleRiskChange = (event: any) => {
        setRiskPerTrade(event.target.value);
    };

    const deleteTips = async () => {
        if (isTipDelete) {
            await deleteTip(tipId);
            await getTips('');
        } else {
            await deleteRule(ruleId);
            await getRules('');
        }
        setIsTipDelete(false);
        setShowDeleteModal(false);

    }

    const openDeleteModal = async (data: any, title: string) => {
        setDeleteTitle(title);
        if (data.tip) {
            setIsTipDelete(true);
            setDeleteMessage('Are you sure you want to delete this tip' + data.tip);
            setTipName(data.tip);
            setTipId(data.id);
        } else {
            setIsTipDelete(false);
            setDeleteMessage('Are you sure you want to delete this rule' + data.rule);
            setRuleName(data.tip);
            setRuleId(data.id);
        }
        setShowDeleteModal(true);
    };

    const handleClose = () => {
        setShowRule(false);
        setShowTip(false);
        setShowDeleteModal(false);
    };

    const openEditRuleModal = (rule: Rule) => {
        setRuleName(rule.rule);
        setRuleId(rule.id);
        setShowRule(true);
    };

    const openEditTipModal = (tip: Tip) => {
        setTipName(tip.tip);
        setTipId(tip.id);
        setShowTip(true);
    };

    const openCreateTipModal = () => {
        setTipName('');
        setCreateTip(true);
        setShowTip(true);
    };

    const openCreateRuleModal = () => {
        setRuleName('');
        setCreateRule(true);
        setShowRule(true);
    }


    const handleRuleSubmit = async (e: any) => {
        e.preventDefault();
        if (createRule) {
            await createNewRule({
                rule: ruleName,
                trading_plan: false
            });
        } else {
            const ruleBody = {
                rule: ruleName,
                trading_plan: false
            };
            await editRule({
                rule: ruleBody,
                ruleId
            }, );
        }
        getRules('');
        handleClose();
    };

    const handleTipSubmit = async (e: any) => {
        e.preventDefault();
        if (createTip) {
            await createNewTip({
                tip: tipName
            });
        } else {
            await editTip({
                tip: {tip: tipName},
                tipId
            }, );
        }
        getTips('');
        handleClose();
    };

    // useEffect(() => {
    //     getRules('');
    //     getTips('');
    // }, []);

    return (
        <Layout>
            <div>
                <Container fluid className='mb-3'>
                    <Row>
                        <Col>
                            <h2 className='mt-3'>Trading Plan</h2>
                            <Form.Group controlId="riskPerTrade">
                                <Form.Label>Risk per Trade</Form.Label>
                                <Form.Control
                                    type="number"
                                    value={riskPerTrade}
                                    onChange={handleRiskChange}
                                    placeholder="Enter risk per trade"
                                    required
                                />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a valid risk per trade.
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Col>
                    </Row>
                </Container>
                <div className="d-flex">
                    <RuleTable
                        rules={rules}
                        openCreateRuleModal={openCreateRuleModal}
                        openEditRuleModal={openEditRuleModal}
                        openDeleteModal={openDeleteModal}
                    />
                    <TipTable
                        tips={tips}
                        openCreateTipModal={openCreateTipModal}
                        openEditTipModal={openEditTipModal}
                        openDeleteModal={openDeleteModal}
                    />
                </div>
            </div>

            <CustomModal
                show={showRule}
                handleClose={handleClose}
                title={createRule ? 'Create new rule' : 'Edit Rule'}
                actionTitle={createRule ? 'Create' : 'Edit'}
                content={
                    <form className="container">
                        <div className="row mb-12">
                            <label className="form-label">Rule name</label>
                            <input
                                type="text"
                                value={ruleName}
                                onChange={(e) => setRuleName(e.target.value)}
                                placeholder="Rule name"
                                className="form-control"
                            />
                        </div>
                    </form>
                }
                onSubmit={handleRuleSubmit}
            />

            <CustomModal
                show={showTip}
                handleClose={handleClose}
                title={createTip ? 'Create new tip' : 'Edit tip'}
                actionTitle={createTip ? 'Create' : 'Edit'}
                content={
                    <form className="container">
                        <div className="row mb-12">
                            <label className="form-label">Tip name</label>
                            <input
                                type="text"
                                value={tipName}
                                onChange={(e) => setTipName(e.target.value)}
                                placeholder="Tip name"
                                className="form-control"
                            />
                        </div>
                    </form>
                }
                onSubmit={handleTipSubmit}
            />

            <CustomModal
                show={showDeleteModal}
                handleClose={handleClose}
                title={deleteTitle}
                confirmButtonVariant='danger'
                actionTitle='Delete'
                content={
                    <p>{deleteMessage}</p>
                }
                onSubmit={() => deleteTips()}
            />
        </Layout>
    );
}

export default TradingPlan;
