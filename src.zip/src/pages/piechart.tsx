import React from 'react';
import Chart from 'react-apexcharts';

const PairsPieChart = ({ chartPairData }: any) => {
    if (!chartPairData || chartPairData.length === 0) {
        return null;
    }

    const chartData = chartPairData.map((entry: any) => ({
        x: entry.name,
        y: parseInt(entry.value),
    }));

    const chartOptions: any = {
        chart: {
            type: 'pie',
        },
        labels: chartData.map((entry: any) => entry.x),
    };

    const series = chartData.map((entry: any) => entry.y);

    const containerStyle = {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%',
    };

    return (
        <div style={containerStyle}>
            <Chart options={chartOptions} series={series} type="pie" width={400} height={400} />
        </div>
    );
};

export default PairsPieChart;
