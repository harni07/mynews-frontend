import React, {useEffect, useState} from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import Layout from "../components/layout";
import {useUpdateAccountMutation} from "../services/auth";

const Profile = () => {
    const [updateUser, { data }] = useUpdateAccountMutation();
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [username, setUsername] = useState('');
    const registerState: any = localStorage.getItem('token');

    useEffect(() => {
        const token = JSON.parse(registerState);
        setFirstName(token.first_name);
        setLastName(token.last_name);
        setUsername(token.username);
    }, []);

    useEffect(() => {
        if (data) {
            let token = JSON.parse(registerState);
            if (token) {
                token.first_name = data.first_name;
                token.last_name = data.last_name;
                token.username = data.username;

                localStorage.setItem('token', JSON.stringify(token));

                setFirstName(data.first_name);
                setLastName(data.last_name);
                setUsername(data.username);
            }
        }
    }, [data]);

    const handleSubmit = async (e: any) => {
        e.preventDefault();
        await updateUser({ id: JSON.parse(registerState).id, first_name: firstName, last_name: lastName, username });
    };

    return (
        <Layout>
            <Container>
                <Row className="justify-content-md-center">
                    <Col xs={12} md={6}>
                        <h2 className="text-center mb-4">Profile</h2>
                        <Form onSubmit={handleSubmit}>
                            <Form.Group controlId="formFirstName">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control
                                    required
                                    type="text"
                                    placeholder="Enter first name"
                                    value={firstName}
                                    onChange={(e) => setFirstName(e.target.value)}
                                />
                            </Form.Group>

                            <Form.Group controlId="formLastName" className="mt-3">
                                <Form.Label>Last Name</Form.Label>
                                <Form.Control
                                    required
                                    type="text"
                                    placeholder="Enter last name"
                                    value={lastName}
                                    onChange={(e) => setLastName(e.target.value)}
                                />
                            </Form.Group>

                            <Form.Group controlId="formUsername" className="mt-3">
                                <Form.Label>Username</Form.Label>
                                <Form.Control
                                    required
                                    type="text"
                                    placeholder="Enter username"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                />
                            </Form.Group>

                            <Button variant="primary" type="submit" className="mt-4">
                                Save Changes
                            </Button>
                        </Form>
                    </Col>
                </Row>
            </Container>
        </Layout>
    );
};

export default Profile;
