import React from 'react';
import {useActivateAccountMutation} from "../services/auth";
import {useParams} from "react-router-dom";

const AccountActivated = () =>  {

    let { token } = useParams();
    const [activateAccount, {data}] = useActivateAccountMutation();

    const activate = () => {
            activateAccount(token);
    }

    return (
        <div className="login-container">
            <div className="image-container">
                <img src="https://st2.depositphotos.com/1003476/8276/i/950/depositphotos_82767358-stock-photo-forex-candlestick-chart-over-dark.jpg" alt="test" />
            </div>
            <div className="form-container">
                <div className="box">
                    <div className="form">
                        {!data && <h2>Activate your account</h2>}
                        {!data && (
                            <button onClick={() => activate()} className="activate-button">Activate account</button>
                        )}
                        {data && <h2>Account activated!</h2>}

                        <div className="links">
                            <a href='/login'>Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

};

export default AccountActivated;
