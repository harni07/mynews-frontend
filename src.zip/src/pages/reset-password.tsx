import React, { useState } from 'react';
import { useParams } from 'react-router-dom';

const ResetPassword = () => {
    const [password, setPassword] = useState('');
    const [repeatPassword, setRepeatPassword] = useState('');
    const { token } = useParams();

    const handleSubmit = async (event: any) => {
        event.preventDefault();

        try {
            console.log('ttt');
        } catch (error) {
            console.error(error);
        }
    };


    return (
        <div className="login-container">
            <div className="image-container">
                <img src="https://st2.depositphotos.com/1003476/8276/i/950/depositphotos_82767358-stock-photo-forex-candlestick-chart-over-dark.jpg" alt="test" />
            </div>
            <div className="form-container">
                <div className="box">
                    <div className="form">
                        <form onSubmit={handleSubmit}>
                            <h2>Reset your password</h2>
                            <div className="inputBox">
                                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
                                <span>New Password</span>
                            </div>
                            <div className="inputBox">
                                <input type="password" required value={repeatPassword} onChange={(e) => setRepeatPassword(e.target.value)} />
                                <span>Repeat Password</span>
                            </div>
                            <div className="links">
                                <a href='/login'>Login</a>
                            </div>
                            <input className='mt-4' type="submit" value="Reset Password" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );

};

export default ResetPassword;
