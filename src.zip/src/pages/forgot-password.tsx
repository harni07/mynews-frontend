import React, { useState } from 'react';
import {useForgotPasswordMutation} from "../services/auth";

const ForgotPassword = () => {
    const [email, setEmail] = useState('');

    const [sendEmail, { data }] = useForgotPasswordMutation();

    const handleSubmit = async (event: any) => {
        event.preventDefault();

        try {
            sendEmail({email: email});
        } catch (error) {
            console.error(error);
        }
    };


    return (
        <div className="login-container">
            <div className="image-container">
                <img src="https://st2.depositphotos.com/1003476/8276/i/950/depositphotos_82767358-stock-photo-forex-candlestick-chart-over-dark.jpg" alt="test" />
            </div>
            <div className="form-container">
                <div className="box">
                    <div className="form">
                        <form onSubmit={handleSubmit}>
                            <h2>Forgot password</h2>
                            <p>Enter your email and we will send you the link on how to reset your password</p>
                            <div className="inputBox">
                                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
                                <span>Email</span>
                                <i></i>
                            </div>
                            <div className="links">
                                <a href='/login'>Login</a>
                                <a href='/register'>Register</a>
                            </div>
                            <input type="submit" value="Send email"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );

};

export default ForgotPassword;
