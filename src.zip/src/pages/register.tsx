import '../App.css';
import React, {useEffect, useState} from 'react';
import {useRegisterMutation} from "../services/auth";
import {Col, Form} from "react-bootstrap";

const Register = () => {
    const [email, setEmail] = useState('');
    const [errors, setErrors] = useState({
        first_name: '',
        last_name: '',
        username: '',
        email: '',
        password: '',
    });
    const [password, setPassword] = useState('');
    const [first_name, setFirstName] = useState('');
    const [last_name, setLastName] = useState('');
    const [username, setUsername] = useState('');
    let [registerUser, { data: response }] = useRegisterMutation();

    const handleSubmit = async (event: any) => {
        event.preventDefault();

        const isValid = validateFields();

        console.log(isValid, 'sta');
        if (isValid) {
            registerUser({ first_name, last_name, email, username, password }).unwrap();

        }

    };

    const validateFields = () => {
        let newErrors = {
            first_name: '',
            last_name: '',
            username: '',
            email: '',
            password: '',
        };

        let isValid = true;

        if (!first_name) {
            isValid = false;
            newErrors.first_name = "First name is required.";
        }
        if (!last_name){
            isValid = false; newErrors.last_name = "Last name is required.";
        }
        if (!username) {
            isValid = false;
            newErrors.username = "Username is required.";
        }
        if (!email) {
            isValid = false;
            newErrors.email = "Email is required.";
        }
        if (!password) {
            isValid = false;
            newErrors.password = "Password is required.";
        }

        setErrors(newErrors);

        // If no errors, return true. Otherwise, return false.
        return isValid;
    };

    const validateEmail = (email: string) => {
        const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        return regex.test(email);
    }

    const handleEmailValidation = (e: any) => {
        const val = e.target.value;
        setEmail(val);
        if (!validateEmail(val)) {
            errors.email = "Please enter a valid email";
            setErrors(errors);
        }
    }

    return (
        <div className="login-container">
            <div className="image-container">
                <img src="https://st2.depositphotos.com/1003476/8276/i/950/depositphotos_82767358-stock-photo-forex-candlestick-chart-over-dark.jpg" alt="test" />
            </div>
            <div className="form-container">
                <div className="box">
                    <div className="form">
                        <form onSubmit={handleSubmit}>
                            <h2>Register</h2>
                            <div className="inputBox">
                                <input type="text" required value={first_name} onChange={(e) => setFirstName(e.target.value)}/>
                                <span>First Name</span>
                                <i></i>
                            </div>
                            {errors.first_name && <p className='text-danger'>{errors.first_name}</p>}
                            <div className="inputBox">
                                <input type="text" required value={last_name} onChange={(e) => setLastName(e.target.value)}/>
                                <span>Last Name</span>
                                <i></i>
                            </div>
                            {errors.last_name && <p className='text-danger'>{errors.last_name}</p>}
                            <div className="inputBox">
                                <input type="text" required value={username} onChange={(e) => setUsername(e.target.value)}/>
                                <span>Username</span>
                                <i></i>
                            </div>
                            {errors.username && <p className='text-danger'>{errors.username}</p>}
                            <div className="inputBox">
                                <input type="email" required value={email} onChange={(e) => handleEmailValidation(e)}/>
                                <span>Email</span>
                                <i></i>
                            </div>
                            {errors.email && <p className='text-danger'>{errors.email}</p>}
                            <div className="inputBox">
                                <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
                                <span>Password</span>
                                <i></i>
                            </div>
                            {errors.password && <p className='text-danger'>{errors.password}</p>}
                            {response && <p className='text-primary'>{response.message}</p>}
                            <div className="links">
                                <a href='/login' className="mt-2">Login</a>
                            </div>
                            <input type="submit" className='mt-3' value="Register"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;
