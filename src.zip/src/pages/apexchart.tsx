import React from 'react';
import ApexChart from 'react-apexcharts';

const ZoomableTimeseriesChart = ({series, chartTitle} : any) => {
    const chartOptions: any = {
        chart: {
            type: 'area',
            stacked: false,
            zoom: {
                type: 'x',
                enabled: true,
                autoScaleYaxis: true,
            },
        },
        dataLabels: {
            enabled: false,
        },
        markers: {
            size: 0,
        },
        title: {
            text: '',
            align: 'left',
        },
        xaxis: {
            type: 'datetime',
        },
        yaxis: {
            title: {
                text: 'Value',
            },
            labels: {
                formatter: function (val: number) {
                    return val.toFixed(2);
                }
            }
        },
        tooltip: {
            shared: false,
            x: {
                format: 'dd MMM yyyy',
            },
        },
    };

    chartOptions.title.text = chartTitle;

    return (
        <ApexChart options={chartOptions} series={series} type="area" height={350} />
    );
};

export default ZoomableTimeseriesChart;
