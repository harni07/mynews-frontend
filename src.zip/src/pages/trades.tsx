import React, {useEffect, useState} from 'react';
import Layout from "../components/layout";
import {useDeleteTradeMutation, useGetTradesMutation} from "../services/trades";
import '../styles/components/trades.scss';
import TradeModal from "../components/modal";
import Pagination from "../components/pagination";
import TradesTable from "../components/table";

const Trades = () => {
    const [getTrades, { data }] = useGetTradesMutation();
    const [sendDeleteTrade] = useDeleteTradeMutation();

    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 8;

    const handlePageChange = (newPage: number) => {
        setCurrentPage(newPage);
        getTrades({ page: newPage, limit: itemsPerPage });
    };

    useEffect(() => {
        getTrades('');
        setCurrentPage(currentPage);
    }, []);



    const deleteTrade = async (tradeId: number, closeModal: () => void) => {
        await sendDeleteTrade(tradeId);
        await getTrades('');
        closeModal();
    }

    const handleCloseModal = () => {
        getTrades('');
    }

        return (
        <Layout>
            <h2 className='mt-3'>Trades</h2>
            <div className='mb-3'>
                <TradeModal buttonTitle='Create new trade' buttonClass={'journal-button'} onTradeSaved={handleCloseModal}/>
            </div>
            <TradesTable
                data={data}
                deleteTrade={deleteTrade}
                handleCloseModal={handleCloseModal}
            />
            <Pagination
                currentPage={currentPage|| 0}
                totalItems={data?.count || 0}
                itemsPerPage={data?.results|| 3}
                onPageChange={handlePageChange}
            />
        </Layout>
    );
}

export default Trades;
