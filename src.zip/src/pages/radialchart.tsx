import React from 'react';
import ReactApexChart from 'react-apexcharts';

const RadialChart = () => {
    const options = {
        plotOptions: {
            radialBar: {
                hollow: {
                    size: '70%',
                }
            },
        },
        labels: ['Progress'],
    };

    const series = [70];

    return <ReactApexChart options={options} series={series} type="radialBar" height={350} />;
};

export default RadialChart;
