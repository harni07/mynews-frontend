import React, {useEffect} from 'react';
import Layout from "../components/layout";
import {useGetDashboardMutation} from "../services/trades";
import Stats from "./stats";
import ZoomableTimeseriesChart from "./apexchart";
import PairsPieChart from "./piechart";
import CandlestickChart from "./candlestickchart";
import ProgressChart from "./progresChart";
import DashboardContainer from "../components/dashboardContainer";

const Dashboard = () => {

    const gradients = [ 'red, purple', 'purple, blue', 'yellow, red', 'yellow, red',]

    const [getDashboardData, { data }] = useGetDashboardMutation();

    useEffect( () => {
        getDashboardData('');
    }, []);

    return (
        <Layout>
            <h2 className='mt-3 mb-3'>Dashboard</h2>
            <Stats
                total_trades={data?.totalTrades}
                num_buys={data?.totalBuys}
                num_sells={data?.totalSells}
                num_pips={data?.totalPips}
                win_ratio={data?.win_ratio}
                outcome={data?.totalOutcome}
                num_mistakes={data?.totalMistakes}
                most_traded_pair={data?.mostTradedPair}
            />

            <div className="chart-container mt-3">
                <div className="row">
                    <DashboardContainer title='Pips per Day'
                                        component={ZoomableTimeseriesChart}
                                        props={{series:[
                                                {
                                                    data: data?.pipsByDate,
                                                }
                                            ]}}/>
                    <div className="col-md-6">
                        <div className="container-style">
                            <h3>Pips per day</h3>
                            <ZoomableTimeseriesChart
                                chartTitle='Pips per day'
                                series={[
                                    {
                                        data: data?.pipsByDate,
                                    },
                                ]} />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="container-style">
                            <h3>Profit per day</h3>
                            <ZoomableTimeseriesChart
                                chartTitle='Profit per day'
                                series={[
                                    {
                                        data: data?.profitByDate,
                                    },
                                ]} />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="container-style">
                            <h3>Pips per day(candlestick chart)</h3>
                            <CandlestickChart candlestickData={data?.candleStickChartPipsData} />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="container-style">
                            <h3>Profit per day(candlestick chart)</h3>
                            <CandlestickChart candlestickData={data?.candleStickChartProfitData} />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="container-style">
                            <h3>Trades per day</h3>
                            <ZoomableTimeseriesChart
                                chartTitle='Trades per day'
                                series={[
                                    {
                                        data: data?.tradesByDate,
                                    },
                                ]} />
                        </div>
                    </div>
                    <div  className="col-md-6">
                        <div className="container-style">
                            <h3>Pairs traded by percantage</h3>
                            <PairsPieChart chartPairData={data?.chartPairData} />
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="container-style">
                            <h3>Win rate by each traded pair</h3>
                            {data?.chartPairWinrateData?.map((el: any, index: number) => (
                                <ProgressChart
                                    title={el.labelsData}
                                    percentage={el.seriesData}
                                    colorGradient={gradients[index]} />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    );
}

export default Dashboard;
