import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import {APP_API_BASE} from "./constants";

export const authApi = createApi({
    reducerPath: 'auth',
    baseQuery: fetchBaseQuery(
        {baseUrl: APP_API_BASE}),
    endpoints: (builder) => ({
        register: builder.mutation({
            query: (user) => ({
                url: 'auth/register',
                method: 'POST',
                body: user,
            }),
        }),
        login: builder.mutation({
            query: (user) => ({
                url: 'auth/login',
                method: 'POST',
                body: user,
            }),
        }),
        activateAccount: builder.mutation({
            query: (token) => ({
                url: 'auth/activate/' + token,
                method: 'GET',
            }),
        }),
        forgotPassword: builder.mutation({
            query: (email) => ({
                url: 'auth/forgot-password',
                method: 'POST',
                body: email,
            }),
        }),
        updateAccount: builder.mutation({
            query: (user) => ({
                url: 'auth/user',
                method: 'PATCH',
                body: user,
            }),
        }),


    }),
})

export const { useRegisterMutation, useLoginMutation, useActivateAccountMutation, useForgotPasswordMutation, useUpdateAccountMutation } = authApi;
