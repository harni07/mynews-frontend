import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import {APP_API_BASE} from "./constants";
import {prepareHeaders} from "../utils/apiUtils";

    export const tradesApi = createApi({
    reducerPath: 'trades',
    baseQuery: fetchBaseQuery(
        {
            baseUrl: APP_API_BASE,
            prepareHeaders: prepareHeaders,
        }),
    endpoints: (builder) => ({
        getTrades: builder.mutation({
            query: ({ page = 1, limit = 8 }) => {
                return {
                    url: `trades?pageNumber=${page}&resultsPerPage=${limit}`,
                    method: 'GET',
                };
            },
        }),
        getDashboard: builder.mutation({
            query: () => ({
                url: `trades/summary`,
                method: 'GET',
            }),
        }),
        createTrade: builder.mutation({
            query: (trade) => ({
                url: 'trades',
                method: 'POST',
                body: trade
            }),
        }),
        updateTrade: builder.mutation({
            query: ({ trade, tradeId })  => ({
                url: 'trades/' + tradeId,
                method: 'PUT',
                body: trade
            }),
        }),
        deleteTrade: builder.mutation({
            query: (tradeId) => ({
                url: 'trades/' + tradeId,
                method: 'DELETE',
            }),
        })


    }),
})

export const {
        useGetTradesMutation,
        useCreateTradeMutation,
        useUpdateTradeMutation,
        useDeleteTradeMutation,
        useGetDashboardMutation
    } = tradesApi;
