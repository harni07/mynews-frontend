import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import {APP_API_BASE} from "./constants";
import {prepareHeaders} from "../utils/apiUtils";


export const tradingPlanApi = createApi({
    reducerPath: 'tradingPlan',
    baseQuery: fetchBaseQuery(
        {
            baseUrl: APP_API_BASE,
            prepareHeaders: prepareHeaders,
        }),
    endpoints: (builder) => ({
        getTradingPlan: builder.mutation({
            query: () => ({
                url: `trading-plan`,
                method: 'GET'
            }),
        }),
        editTradingPlan: builder.mutation({
            query: () => ({
                url: `trading-plan`,
                method: 'GET'
            }),
        }),
        getRules: builder.mutation({
            query: ({ page = 1, limit = 10 }) => ({
                // url: `rules?pageNumber=${page}&resultsPerPage=${limit}`,
                url: `rules`,
                method: 'GET'
            }),
        }),
        createRule: builder.mutation({
            query: (rule) => ({
                url: `rules`,
                method: 'POST',
                body: rule
            }),
        }),
        editRule: builder.mutation({
            query: ({ rule, ruleId})  => ({
                url: `rules/` + ruleId,
                method: 'PATCH',
                body: rule
            }),
        }),
        deleteRule: builder.mutation({
            query: (ruleId) => ({
                url: 'rules/' + ruleId,
                method: 'DELETE'
            }),
        }),
        getTips: builder.mutation({
            query: ({ page = 1, limit = 10 }) => ({
                // url: `rules?pageNumber=${page}&resultsPerPage=${limit}`,
                url: `tips`,
                method: 'GET'
            }),
        }),
        createTip: builder.mutation({
            query: (tip) => ({
                url: `tips`,
                method: 'POST',
                body: tip
            }),
        }),
        editTip: builder.mutation({
            query: ({ tip, tipId })  => ({
                url: 'tips/' + tipId,
                method: 'PATCH',
                body: tip
            }),
        }),
        deleteTip: builder.mutation({
            query: (tipId) => ({
                url: 'tips/' + tipId,
                method: 'DELETE'
            }),
        })


    }),
})

export const {
    useGetTradingPlanMutation,
    useEditTradingPlanMutation,
    useGetRulesMutation,
    useCreateRuleMutation,
    useEditRuleMutation,
    useDeleteRuleMutation,
    useGetTipsMutation,
    useCreateTipMutation,
    useEditTipMutation,
    useDeleteTipMutation
} = tradingPlanApi;
